package com.example.testgetcli_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
