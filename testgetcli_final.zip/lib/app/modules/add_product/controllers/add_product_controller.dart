import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class AddProductController extends GetxController {
  //TODO: Implement AddProductController

  TextEditingController nameC = TextEditingController();
  TextEditingController priceC = TextEditingController();
    
  
}
